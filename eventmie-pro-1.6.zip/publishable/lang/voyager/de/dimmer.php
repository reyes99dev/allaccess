<?php

return [
    'page'           => 'Seite|Seiten',
    'page_link_text' => 'Alle Seiten anzeigen',
    'page_text'      => 'Sie haben :count :string in Ihrer Datenbank.',
    'post'           => 'Post|Posts',
    'post_link_text' => 'Alle Posts anzeigen',
    'post_text'      => 'Sie haben :count :string in Ihrer Datenbank.',
    'user'           => 'Benutzer|Benutzer',
    'user_link_text' => 'Alle Benutzer anzeigen',
    'user_text'      => 'Sie haben :count :string in Ihrer Datenbank.',
];
