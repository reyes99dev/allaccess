<?php

return [
    'loggingin'    => '正在登录',
    'signin_below' => '在下方登录：',
    'welcome'      => '欢迎使用 Voyager - 不可错过的 Laravel 后台管理框架',
];
