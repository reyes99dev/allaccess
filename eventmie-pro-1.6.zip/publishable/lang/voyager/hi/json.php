<?php

return [
    'invalid'           => 'अमान्य JSON',
    'invalid_message'   => 'लगता है कि आपने कुछ अमान्य JSON पेश किया।',
    'valid'             => 'मान्य जेन्सन',
    'validation_errors' => 'सत्यापन त्रुटियां',
];
