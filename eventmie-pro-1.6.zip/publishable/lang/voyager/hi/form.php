<?php

return [
    'field_password_keep'          => 'खाली रखने के लिए एक ही रखें',
    'field_select_dd_relationship' => 'क्लास क्लास: की विधि पद्धति में उपयुक्त संबंध स्थापित करना सुनिश्चित करें।',
    'type_checkbox'                => 'चेक बॉक्स',
    'type_codeeditor'              => 'कोड संपादक',
    'type_file'                    => 'फ़ाइल',
    'type_image'                   => 'छवि',
    'type_radiobutton'             => 'रेडियो बटन',
    'type_richtextbox'             => 'रिच टेक्स्टबॉक्स',
    'type_selectdropdown'          => 'ड्रॉपडाउन का चयन करें',
    'type_textarea'                => 'पाठ क्षेत्र',
    'type_textbox'                 => 'पाठ बॉक्स',
];
