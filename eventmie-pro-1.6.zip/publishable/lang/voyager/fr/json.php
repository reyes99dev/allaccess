<?php

return [
    'invalid'           => 'Json invalide',
    'invalid_message'   => 'Il semble que votre JSON soit invalide.',
    'valid'             => 'Json valide',
    'validation_errors' => 'Erreurs de validation',
];
