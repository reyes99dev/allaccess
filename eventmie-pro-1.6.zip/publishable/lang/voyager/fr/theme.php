<?php

return [
    'footer_copyright'  => 'Fait avec <i class="voyager-heart"></i> par',
    'footer_copyright2' => 'Fait avec du rhum et encore plus de rhum',
];
