<?php

return [
    'last_week' => '上週',
    'last_year' => '去年',
    'this_week' => '本週',
    'this_year' => '今年',
];
