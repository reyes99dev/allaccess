<li>
    <a class="lgx-scroll" href="{{ route('eventmie.login') }}"><i class="fas fa-fingerprint"></i> @lang('eventmie-pro::em.login')</a>
</li>
<li>
    <a class="lgx-scroll" href="{{ route('eventmie.register_show') }}"><i class="fas fa-user-plus"></i> @lang('eventmie-pro::em.register')</a>
</li>