<?php

namespace Classiebit\Eventmie\Models;

use Illuminate\Database\Eloquent\Model;

class Page extends \TCG\Voyager\Models\Page
{
    protected $translatable = [];
}    